---
name: new-card-unlock
description: Invoke when a retail banking customer needs step-by-step guidance to unlock a newly received card in the mobile app.
---

## Purpose
Guide a customer through unlocking a new card in the mobile app safely and concisely.

## Instructions
1. Confirm from the existing message that the request concerns a new card; ask only if this is genuinely unclear.
2. Provide the app navigation as a numbered list, using generic labels such as Cards, select the new card, and Unlock or Activate when exact labels are not available.
3. If the app path or status is not accessible, state that limitation and tell the customer which card-management screen to open.
4. If the customer reports loss or theft instead of a new-card unlock, route to human support in one sentence, explain the reason, and state what was recorded.
5. Keep the response direct, cordial, and within five lines; never request a password, SMS code, or full card number, and never invent fees, timelines, or protocol numbers.
6. End with a single-line question asking whether the doubt was resolved.

## Parameters
- Customer message and any card status details already provided.

## Output
A short numbered set of safe app steps or a concise human-support handoff.