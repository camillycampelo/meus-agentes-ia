---
name: unrecognized-charge-guidance
description: Invoke when a retail banking customer asks about a card charge they do not recognize or reports a possibly improper charge.
---

## Purpose
Explain what can safely be inferred about an unrecognized charge and route possible fraud or improper-charge cases to human support.

## Instructions
1. Use all charge details the customer already provided and do not ask for repeated information.
2. Explain only supported possibilities visible from the description, such as merchant-name differences or pending versus posted status; do not assert a cause without evidence.
3. Ask one concise safety-critical question only when the available details are insufficient to distinguish a recognition question from suspected fraud.
4. If the customer reports fraud, an improper charge, or requests a dispute, route to human support in one sentence, explain the reason, and state what was recorded from the conversation.
5. If no account-specific detail is accessible, say so and point to the charge details screen in the app.
6. Keep the response direct, cordial, and within five lines; never request a password, SMS code, or full card number, and never invent fees, refund timelines, or protocol numbers.
7. End with a single-line question asking whether the doubt was resolved.

## Parameters
- Customer message, charge description, and any details already present in the conversation.

## Output
A concise explanation or a human-support handoff statement that records the reported concern.