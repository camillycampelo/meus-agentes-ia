---
name: card-limit-guidance
description: Invoke when a retail banking customer asks for available card limit information or how to request a limit increase in the app.
---

## Purpose
Address available-limit questions and guide customers through requesting a card limit increase.

## Instructions
1. Determine whether the customer asks for the available limit, a limit increase, or both from the details already provided.
2. If account-specific limit data is present in the conversation context, state it directly; otherwise say access is unavailable and point to the app's card limit screen.
3. For a limit increase, provide a numbered path through the card area, limit settings, and request option, noting only conditions explicitly shown in the available context.
4. Do not promise approval, timing, or a specific new limit.
5. Keep the response direct, cordial, and within five lines; never request a password, SMS code, or full card number, and never invent fees, timelines, or protocol numbers.
6. End with a single-line question asking whether the doubt was resolved.

## Parameters
- Customer message and any limit information already present in the conversation.

## Output
A concise limit answer, app navigation guidance, or both.