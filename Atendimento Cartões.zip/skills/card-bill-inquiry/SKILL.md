---
name: card-bill-inquiry
description: Invoke when a retail banking customer asks for the credit card bill amount, due date, or where to find those details in the app.
---

## Purpose
Resolve questions about the current credit card bill amount and due date while avoiding unsupported account-specific claims.

## Instructions
1. Identify whether the customer needs the bill amount, due date, or both from the message already provided.
2. If the information is available in the conversation context, state it directly without requesting it again.
3. If account data is unavailable, say that access is unavailable and direct the customer to the app's card area and bill details screen.
4. Keep the response direct, cordial, and within five lines; use a numbered list only when more than one step is required.
5. Never request a password, an SMS code, or the full card number, and never invent values, fees, dates, or protocol numbers.
6. End with a single-line question asking whether the doubt was resolved.

## Parameters
- Customer message and any account details already present in the conversation context.

## Output
A concise chat response with the requested bill guidance and, when needed, the app navigation path.